function createDataset(fields, constraints, sortFields) {
	var dataset = DatasetBuilder.newDataset();
	var datasetFields = new Array("docId","docVersion", "codTreinamento", "nomeTreinamento");
	
	for (var i = 0; i < datasetFields.length; i++) {
		dataset.addColumn(datasetFields[i]);
	}
	
	try{
		//Cria a constraint para buscar os formul?rios ativos
		var c1 = DatasetFactory.createConstraint("metadata#active", true, true, ConstraintType.MUST);
		var constraints = new Array(c1);
		
		var datasetPrincipal = DatasetFactory.getDataset("treinamento", null, constraints, null);
		var datasetFilhos = {};
		
		//Cria as constraints para buscar os campos filhos, passando o tablename, n?mero da formul?rio e vers?o
		var c1 = DatasetFactory.createConstraint("tablename", "tbTreinamento" ,"tbTreinamento", ConstraintType.MUST);
		
		if(datasetPrincipal.rowsCount > 0) {
			for(var i = 0; i < datasetPrincipal.rowsCount; i++) {
		        var documentId = datasetPrincipal.getValue(i, "metadata#id");
		        var documentVersion = datasetPrincipal.getValue(i, "metadata#version");
		         
		        //Cria as constraints para buscar os campos filhos, passando o tablename, n?mero da formul?rio e vers?o
		        var c2 = DatasetFactory.createConstraint("metadata#id", documentId, documentId, ConstraintType.MUST);
		        var c3 = DatasetFactory.createConstraint("metadata#version", documentVersion, documentVersion, ConstraintType.MUST);
		        var constraintsFilhos = new Array(c1, c2, c3);
		
		        datasetFilhos = DatasetFactory.getDataset("treinamento", null, constraintsFilhos, null);
		        
		        for (var j = 0; j < datasetFilhos.rowsCount; j++) {
		            //Adiciona os valores nas colunas respectivamente.
		            dataset.addRow(new Array(
		            	documentId,
		            	documentVersion,
			            datasetFilhos.getValue(j, "codTreinamento"),
			            datasetFilhos.getValue(j, "nomeTreinamento")
		            ));
		        }
			}
		
		}else{
			//trata o dataset vazio
			dataset.addRow( new Array('','','','','') );			
		}
		
	}catch(e){
		msgError = "Erro ao carregar os Tipos de Servicos: " + e;
		log.error(msgError);
		dataset.addColumn("erro");
		dataset.addRow (new Array(msgError));
	}
	
	return dataset;
}