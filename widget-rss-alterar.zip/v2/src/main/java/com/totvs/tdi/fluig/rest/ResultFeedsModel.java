package com.totvs.tdi.fluig.rest;

public class ResultFeedsModel{
	
	private String componente;
	private String dados;
	
	public ResultFeedsModel(String componente, String dados) {
		this.componente = componente;
		this.dados = dados;
	}
	
	public String getComponente() {
		return componente;
	}
	public void setComponente(String componente) {
		this.componente = componente;
	}
	public String getDados() {
		return dados;
	}
	public void setDados(String dados) {
		this.dados = dados;
	}

	
}
