package com.totvs.tdi.fluig.rest;

@javax.ws.rs.ApplicationPath("api/rest")
public class ApplicationConfig extends javax.ws.rs.core.Application {
}