package com.totvs.tdi.fluig.rest;

import com.sun.syndication.feed.synd.SyndEntryImpl;
import com.sun.syndication.feed.synd.SyndFeed;
import com.sun.syndication.io.SyndFeedInput;
import com.sun.syndication.io.XmlReader;
import com.totvs.technology.wcm.common.WCMRestResult;
import com.totvs.technology.wcm.sdk.rest.WCMRest;

import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import java.io.Serializable;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

@Path("/rss")
public class RSSRest extends WCMRest {
	private static Logger log = LoggerFactory.getLogger(RSSRest.class);

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public Response doSomething(RSSParamsVO pars) {

		try {
			if(pars.limit == null)
				pars.limit = 9;

			URL feedUrl = new URL(pars.url);

			SyndFeedInput input = new SyndFeedInput();
			SyndFeed feeds = input.build(new XmlReader(feedUrl));

			List<SyndEntryImpl> retFeeds = feeds.getEntries();

			JSONArray arr = new JSONArray();

			SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
			
			List<ResultFeedsModel> feedsModels = new ArrayList<ResultFeedsModel>();
			
			for(int i = pars.init; i < pars.limit ; i++){
				
				if(retFeeds.get(i).getTitle() !=null)
					feedsModels.add(new ResultFeedsModel("title", retFeeds.get(i).getTitle()));
				
				
				if(retFeeds.get(i).getLink() !=null)
					feedsModels.add(new ResultFeedsModel("link", retFeeds.get(i).getLink()));
				
				
				if(retFeeds.get(i).getDescription().getValue() !=null)
					feedsModels.add(new ResultFeedsModel("desc", retFeeds.get(i).getDescription().getValue()));
				
				
				if(retFeeds.get(i).getPublishedDate() !=null)
					feedsModels.add(new ResultFeedsModel("date", DATE_FORMAT.format(retFeeds.get(i).getPublishedDate())));
				
				}
	
			for(ResultFeedsModel feedsModel : feedsModels){
				JSONObject o = new JSONObject();
				o.put(feedsModel.getComponente(), feedsModel.getDados());
				arr.put(o);
			}
			
			return this.buildJSONResponse(new WCMRestResult(arr.toString()));
		} catch (Exception ex) {
			log.error("Houve algum problema no XML RSS", ex);
			return this.buildJSONResponse(ex, super.getWCMSDK().getLocale());
		}
	}
}

class RSSParamsVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public String url;
	public Integer init;
	public Integer limit;
}
