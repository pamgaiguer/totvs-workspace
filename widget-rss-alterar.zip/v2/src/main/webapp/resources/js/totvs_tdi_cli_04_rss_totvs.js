var totvs_tdi_cli_04_rss_totvsObj = SuperWidget.extend({
	instanceId: null,
	sociableId: null,

	bindings: {
		local: {
			'bt-save': ['click_paramsSave']
		}
	},

	init: function() {
		//code

		if(this.mode == "edit")
			return;

		if(!this.url_rss)
			this.url_rss = "http://blog.totvs.com/feed/";

		var params = {
			"url": unescape(this.url_rss),
			"limit": 9,
			"init":0
		};

		$.ajax({
			type: "POST",
			dataType: "json",
			url: "/totvs_tdi_cli_04_rss_totvs/api/rest/rss/read",
			data: JSON.stringify(params),
			contentType: "application/json",
			success: function (data, status, xhr) {
				var news = $.parseJSON(data.content);
				for(var cont=0; cont < news.push() ; cont++){
					var new1 = news[cont];

					var divNews = $( "<div/>");
					divNews.addClass("content");
					divNews.appendTo( "div#cli-04-rss-totvs div#news" );

					var aNews = $("<a/>");
					aNews.prop("href", new1.link);
					aNews.prop("target", "_blank");
					aNews.html(new1.desc);
					aNews.appendTo(divNews);

					var divDate = $( "<div/>");
					divDate.addClass("date");
					divDate.text(new1.date);
					divDate.appendTo( divNews );
					
				}

				$( "div#cli-04-rss-totvs div#loading-news" ).hide();
			}
		});
	},

	paramsSave: function(el, ev) {
		var args = {};

		args.url_rss = $('input[id="url_rss"]', this.DOM).val();

		var result = WCMSpaceAPI.PageService.UPDATEPREFERENCES({async:false}, this.instanceId, args);
		if (result) {
			WCMC.messageInfo(result.message);
		} else {
			WCMC.messageError("${i18n.getTranslation('save.error')}");
		}
	}
});
